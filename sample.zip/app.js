/*
 * Copyright (c) 2011, salesforce.com, inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
 * following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
 * the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * Neither the name of salesforce.com, inc. nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
 
 /*
  * This is a simple jQuery-based app that uses the Force.com REST API.
  * See vf.js for code required to run this in Visualforce
  * See custom.js for code required to run this on your own server
  */

  function logout(e) {
  	e.preventDefault();

  	window.location.href = 'https://login.salesforce.com/secur/logout.jsp';
  }
  
  function errorCallback(jqXHR){
      $dialog.dialog('option', 'title', 'Error');
      $dialog.dialog('option', 'modal', true);
      $dialog.html(TrimPath.processDOMTemplate("error_jst", jqXHR));
      $dialog.find('#ok').click(function(e) {
          e.preventDefault();
          $dialog.dialog('close');
          logout(e);
      });
      $dialog.dialog('open');
  }

  function metadataCallback(response){
     // Using TrimPath Template for now - may switch to jQuery Template at some
     // point
 	$j('#prompt').html(TrimPath.processDOMTemplate("prompt_jst"
 	    , response));

     // Set up autocomplete
     $j( "#value" ).autocomplete({
         source: function( request, response ) {
             var query = "SELECT Id, Name FROM Account "+
                 "WHERE "+$j("#field").val()+" LIKE '%"+request.term+"%' "+
                 "ORDER BY Name LIMIT 20";

             client.query(query, function( data ) {
                 response( $j.map( data.records, function( record ) {
                     return {
                         label: record.Name,
                         value: record.Id
                     }
                 }));
             });
         },
         minLength: 2,
         delay: 1000,
         select: function( event, ui ) {
             if ( ui.item != null ) {
                 showAccountDetail(ui.item.value);
             } else {
                 filterAccounts($j("#field").val(),this.value);
             }

             return false;
         },
     });

 	$j('#go').click(function(e) {
         var field = $j("#field").val();
         var value = $j("#value").val();

     	e.preventDefault();
 	    filterAccounts(field,value);
 	});

 	$j('#new').click(function(e) {
     	e.preventDefault();

     	// Just make Trimpath happy
     	var dummy = {};
     	var i;
     	for (i = 0; i < response.fields.length; i++) {
     	    dummy[response.fields[i].name] = '';
     	}
         $dialog.html(TrimPath.processDOMTemplate("edit_jst", dummy));
         $dialog.find('#action').html('Create').click(function(e) {
             e.preventDefault();
             $dialog.dialog('close');

             var fields = {};
             $dialog.find('input').each(function() {
                 var child = $j(this);
                 if ( child.val().length > 0 ) {
                     fields[child.attr("name")] = child.val();  
                 }               
             });

             $j('#list').html(ajaxgif+" creating account...");

             client.create('Account', fields, createCallback);
         });
         $dialog.dialog('option', 'title', 'New Account');
         $dialog.dialog('open');
 	});

 	filterAccounts();
 }

 function queryCallback(response) {
 	$j('#list').html(TrimPath.processDOMTemplate("accounts_jst"
 	    , response));

     $j('#version').html($j.fn.jquery);
     $j('#uiversion').html($j.ui.version);

 	$j("#list tr:nth-child(odd)").addClass("odd");

 	$j('#logout').click(logout);

 	$j('#accounts').find('.id')
 	    .hover(function() {
              $j(this).addClass("highlighted");
            },function(){
              $j(this).removeClass("highlighted");
         })
         .click(function(){
             showAccountDetail(this.id);
         });
 }

 // Make our own startsWith utility fn
 String.prototype.startsWith = function(str){
     return (this.substr(0, str.length) === str);
 }

 function detailCallback(response) {
     if (response.Website != null
     && !response.Website.startsWith('http://')) {
         response.Website = 'http://'+response.Website;
     }
     $dialog.html(TrimPath.processDOMTemplate("detail_jst"
         ,response));
     $dialog.find('#industry').click(function(e) {
         e.preventDefault();
         $dialog.dialog('close');
         filterIndustry($j(this).html());
     });
     $dialog.find('#delete').click(function(e) {
         e.preventDefault();
         $dialog.dialog('close');
         $j('#list').html(ajaxgif+" deleting account...");
         client.del('Account', $dialog.find('#id').val(), deleteCallback);
     });
     $dialog.find('#edit').click(function(e) {
         e.preventDefault();
         $dialog.html(TrimPath.processDOMTemplate("edit_jst"
             ,response));
         $dialog.find('#action').html('Update').click(function(e) {
             e.preventDefault();
             $dialog.dialog('close');

             var fields = {};
             $dialog.find('input').each(function() {
                 var child = $j(this);
                 if ( child.val().length > 0 && child.attr("name") != 'id') {
                     fields[child.attr("name")] = child.val();  
                 }               
             });

             $j('#list').html(ajaxgif+" updating account...");

             client.update('Account', $dialog.find('#id').val(), fields, updateCallback);
         });
     });
 }

 function createCallback(response) {
 	$j('#list').html('Created '+response.id);

 	setTimeout("filterAccounts()",1000);
 }

 function updateCallback(response) {
 	$j('#list').html('Updated');

 	setTimeout("filterAccounts()",1000);
 }

 function deleteCallback(response) {
 	$j('#list').html('Deleted');

 	setTimeout("filterAccounts()",1000);
 }

 function showAccountDetail(id) {
     // Show the dialog
     $dialog.dialog('option', 'title', 'Account Detail');
     $dialog.dialog('open');
     $dialog.html(ajaxgif+" retrieving...");

     // Get account details and populate the dialog
     client.retrieve('Account', id, 'Name,Industry,TickerSymbol,Website'
         , detailCallback);
 }

 function filterIndustry(industry) {
     $j('#list').html(ajaxgif+" loading data...");

     var query = "SELECT Id, Name FROM Account WHERE Industry = '"+industry
     +"' ORDER BY Name LIMIT 20";

     client.query(query, queryCallback);
 }

 function filterAccounts(field, value) {
     $j('#list').html(ajaxgif+" loading data...");

     var query = ( typeof value !== 'undefined' && value.length > 0 ) 
         ? "SELECT Id, Name FROM Account WHERE "+field+" LIKE '%"+value
         +"%' ORDER BY Name LIMIT 20"
         : "SELECT Id, Name FROM Account ORDER BY Name LIMIT 20";

     client.query(query, queryCallback);
 }
 